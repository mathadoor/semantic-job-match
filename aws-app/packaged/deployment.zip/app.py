from chalice import Chalice
from job_scraper.ApifyScraper import ApiFyActor
import boto3

import re
import os

app = Chalice(app_name='swifthire-cloud')

_TITLES = [
    "Machine Learning Engineer",
    "Data Scientist",
    "MLOps Engineer",
    "Data Analyst",
    "Data Engineer"
]

_JOBS_BUCKET_NAME = "swifthire-media-bucket-0"
_JOBS_BUCKET = None
_SCRAPER = None

_NUM_PAGES = 1
_MAX_CONCURRENCY = 10

BASE_QUERIES = {
    "maxPagesPerQuery": _NUM_PAGES,
    "csvFriendlyOutput": False,
    "countryCode": "ca",
    "languageCode": "",
    "maxConcurrency": _MAX_CONCURRENCY,
    "saveHtml": False,
    "saveHtmlToKeyValueStore": False,
    "includeUnfilteredResults": False,
}

_QUERY_URL = "https://www.google.ca/search?q=JOB&ibp=htl;jobs&uule=w+CAIQICIGQ2FuYWRh"

# ELASTIC INPUT
ELASTIC_HOST = 'http://localhost:9200'
INDEX_NAME = 'jobs'


def gen_queries():
    """
    Helper Function to create a query for each searched title

    The parameters used are set at the top of the page as constants.

    Returns
    -------
        queries: A list of queries for each searched title in Titles
    """
    # PROCESS QUERIES TO CREATE A QUERY FOR EACH SEARCHED TITLE
    processed_titles = ["%20".join(title.split()) for title in _TITLES]
    query_urls = [re.sub("JOB", title, _QUERY_URL) for title in processed_titles]

    # PREPARE QUERIES
    queries = []
    for query_url in query_urls:
        query = BASE_QUERIES.copy()
        query["queries"] = query_url
        queries.append(query)

    return queries


def get_bucket():
    """ Helper Function to create a job postings bucket"""
    global _JOBS_BUCKET
    s3 = boto3.resource("s3")

    # Check if the bucket already exists
    _JOBS_BUCKET = s3.Bucket(_JOBS_BUCKET_NAME)
    if _JOBS_BUCKET.creation_date is None:
        _JOBS_BUCKET = s3.create_bucket(Bucket=_JOBS_BUCKET_NAME)

    return _JOBS_BUCKET


def get_scraper():
    """ Helper Function to create a job scraper"""

    global _SCRAPER
    if _SCRAPER is None:
        _SCRAPER = ApiFyActor(os.environ["brave_apify_token"])

    return _SCRAPER


@app.route('/')
def index():
    responses = []
    for query in gen_queries():
        responses.append(get_scraper().run(query))

    return responses


@app.schedule('rate(24 hours)')
def cronjob():
    return {'hello': 'world'}

# The view function above will return {"hello": "world"}
# whenever you make an HTTP GET request to '/'.
#
# Here are a few more examples:
#
# @app.route('/hello/{name}')
# def hello_name(name):
#    # '/hello/james' -> {"hello": "james"}
#    return {'hello': name}
#
# @app.route('/users', methods=['POST'])
# def create_user():
#     # This is the JSON body the user sent in their POST request.
#     user_as_json = app.current_request.json_body
#     # We'll echo the json body back to the user in a 'user' key.
#     return {'user': user_as_json}
#
# See the README documentation for more examples.
#
